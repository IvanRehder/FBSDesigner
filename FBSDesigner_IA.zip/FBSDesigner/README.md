# FBSDesigner

Interface usada na pesquisa de doutorado sobre design de HMI assistido por IA (estudo de caso MUM-T/ISR). Você define, requisito por requisito, como partes da interface devem funcionar usando o método Function-Behaviour-Structure (FBS). Dependendo da sua condição, você conta com o apoio do Claude (condição **IA**) ou trabalha sozinho (condição **Human**).

O contexto da pesquisa, o método FBS, o passo a passo de instalação e o uso detalhado estão no **`manual_usuario.pdf`**, que veio junto desta pasta. Leia-o antes de começar; este README é só um resumo.

---

## 1. Instalação

### O que você precisa
- **Python 3** (qualquer versão recente). Se não tiver, instale em https://www.python.org/downloads/.
  - **Windows:** na instalação, marque **"Add Python to PATH"**.
- Um navegador (Chrome, Firefox, Edge...).
- Internet (a condição IA precisa; a Human só precisa na primeira vez, para instalar os pacotes).
- Condição IA apenas: a **chave de API** que o pesquisador te enviou separadamente.

Não é preciso saber programar nem instalar nada além do Python.

### Passo a passo
1. Extraia o `.zip` recebido numa pasta qualquer (ou, se o pesquisador pediu, clone a branch com `git clone -b <nome-sobrenome> <url>`).
2. Abra a pasta e inicie o app conforme a sua condição (o pesquisador te informa qual é):

| Condição | Windows | Mac / Linux |
|---|---|---|
| IA | dois cliques em `iniciar_ia.bat` | `bash iniciar_ia.sh` num terminal aberto na pasta |
| Human | dois cliques em `iniciar_human.bat` | `bash iniciar_human.sh` num terminal aberto na pasta |

3. **Na primeira vez** demora alguns minutos: o script cria um ambiente próprio e instala os pacotes (inclui o Streamlit). Isso só acontece uma vez.
4. Condição IA: quando pedir, cole a chave de API e aperte Enter. Ela fica salva e não será pedida de novo.
5. O navegador abre sozinho com a interface (endereço `http://localhost:8501`). **Mantenha a janela preta/terminal aberta enquanto usa**; fechá-la encerra o app.

Para abrir de novo depois, repita o mesmo clique/comando. Seu progresso e suas configurações são mantidos.

### Se algo der errado
- **"Python não encontrado":** instale o Python (no Windows, com "Add Python to PATH") e rode de novo.
- **Mac/Linux, "permission denied":** use `bash iniciar_ia.sh` (com o `bash` na frente) em vez de executar o arquivo direto.
- **Janela fecha sozinha / erro estranho:** rode com `--debug` (`iniciar_ia.bat --debug` ou `bash iniciar_ia.sh --debug`) num terminal; ele pausa a cada etapa. Mande uma captura de tela ao pesquisador.
- **Condição IA, chave inválida:** apague o arquivo `.env` da pasta e rode de novo para colar a chave outra vez.
- **A página não abre:** acesse manualmente http://localhost:8501.

---

## 2. Uso

1. **Identificação:** digite o seu número de participante (2 dígitos, passado pelo pesquisador). Na primeira vez, preencha o formulário curto de perfil profissional.
2. **Introdução:** leia as definições do método, o vocabulário de modalidades e o contexto do cenário MUM-T/ISR. Na barra lateral há, a qualquer momento, um **exemplo preenchido** e as **imagens das telas já existentes** do sistema.
3. **Aquecimento:** um problema simples de prática, fora do domínio do projeto, sem IA. Ao terminar, aparece um aviso perguntando se você tem dúvidas antes de seguir.
4. **Requisitos reais (20):** um de cada vez. Para cada requisito você fecha as três camadas, nesta ordem:
   - **Function:** para que serve (o objetivo/efeito). Sem fluxo nem passos.
   - **Behaviour:** o que faz (a sequência "o usuário faz X, o sistema responde Y"), sem componentes concretos.
   - **Structure:** do que é feito (botões, painéis, ícones, alto-falantes...) e **como se relacionam** para viabilizar o Behaviour.

   As modalidades de interação (Touch, Keyboard, Screen, Voice-in, Audio-out, Wearable/HMD, Haptic) já vêm fixadas em cada requisito. Na condição IA você fecha as camadas conversando com o Claude; na Human, escreve sozinho.
5. **Questionário final:** um questionário curto (SUS) sobre a experiência de usar a *ferramenta*, não sobre o sistema desenhado.

**Várias sessões:** você pode parar e voltar quando quiser. Basta abrir o app de novo e digitar o mesmo número de participante: ele retoma de onde parou. O tempo estimado total é de 4 a 6 horas de trabalho ativo.

---

## 3. Devolvendo os resultados

Tudo o que você produz fica salvo na pasta **`out/`**, dentro da pasta do projeto. Quando terminar (ou quando o pesquisador pedir), compacte a pasta `out` num `.zip` e envie ao pesquisador.

**Privacidade:** não é coletado nome, e-mail ou qualquer dado que identifique você diretamente, só o número de participante e as respostas do formulário de perfil profissional.

---

## Para o pesquisador

- Antes de enviar um pacote, confira se não falta nada: `python tools/conferir_pacote.py <pasta>`.
- **Nunca inclua** `.env`, `venv/` ou `out/` no pacote (o `.gitignore` já os exclui do git, mas não de um zip feito à mão). A chave de API vai em mensagem separada.
- A condição Human não precisa dos arquivos de IA (`app_streamlit.py`, `core/fbs_core_ai.py`, `iniciar_ia.*`, `content/mechanics_ai.md`, `content/system_description.txt`, `content/hmi_baseline.txt`, `content/response_style.txt`).
- Painel admin (progresso de cada participante e download dos resultados): abra o app com `?admin=300` na URL.
