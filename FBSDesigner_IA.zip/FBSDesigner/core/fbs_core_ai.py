#!/usr/bin/env python3
"""
FBS core — lógica compartilhada entre o CLI (fbs_design.py) e a
interface gráfica (app_streamlit.py). Sem input()/print() de diálogo.
"""

import anthropic
import json
import os
import time
import streamlit as st
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

MODEL      = "claude-opus-4-8"  # diálogo real (F/Be/S) — aqui a qualidade importa
MODEL_MISC = "claude-sonnet-5"  # tarefas mecânicas (extrair camada fechada, resumir, indexar) — bem mais barato, sem perda perceptível
# preço oficial Anthropic, USD por milhão de tokens (fonte: platform.claude.com/docs/pricing)
PRICE_PER_MTOK = {
    MODEL:      {"input": 5.0, "output": 25.0},
    MODEL_MISC: {"input": 2.0, "output": 10.0},
}
# effort: vai dentro de output_config={"effort": ...}
# Opções (Opus 4.8 e Sonnet 5): "low" | "medium" | "high" | "xhigh" | "max"
EFFORT      = "high"   # diálogo (F/Be/S)
EFFORT_MISC = "low"    # resumos (tarefa trivial)
BASE_OUT_DIR = Path(os.environ.get("FBS_OUT_DIR", "out"))
BASE_OUT_DIR.mkdir(parents=True, exist_ok=True)
CONTENT_DIR = Path("content")

def current_out_dir():
    """A pasta do designer atual. Vive em st.session_state (isolado por
    sessão de verdade) — NUNCA numa variável global do módulo, porque no
    Streamlit Cloud todos os usuários conectados ao mesmo app compartilham
    o mesmo processo Python, e uma variável global mutável vazaria dados
    de um designer pra sessão de outro."""
    return st.session_state.get("out_dir", BASE_OUT_DIR)

def sanitize_designer_id(designer_id):
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in designer_id.strip().lower())

def designer_registered(designer_id):
    safe = sanitize_designer_id(designer_id)
    return (BASE_OUT_DIR / safe / "designer_info.json").exists()

def set_designer(designer_id):
    """Redireciona a pasta do designer atual pra uma subpasta por designer
    (case-insensitive). Chamar antes de qualquer outra função que leia/
    grave dados do designer. Guarda em st.session_state — isolado por
    sessão, ao contrário de uma variável global do módulo."""
    safe = sanitize_designer_id(designer_id)
    d = BASE_OUT_DIR / safe
    d.mkdir(parents=True, exist_ok=True)
    st.session_state.out_dir = d
    return safe

def save_designer_info(info):
    (current_out_dir() / "designer_info.json").write_text(json.dumps(info, indent=2, ensure_ascii=False), encoding="utf-8")

SYSTEM_DESCRIPTION = (CONTENT_DIR / "system_description.txt").read_text(encoding="utf-8")
HMI_BASELINE       = (CONTENT_DIR / "hmi_baseline.txt").read_text(encoding="utf-8")
RESPONSE_STYLE     = (CONTENT_DIR / "response_style.txt").read_text(encoding="utf-8")
REQUIREMENTS       = json.loads((CONTENT_DIR / "requirements.json").read_text(encoding="utf-8"))

LAYERS = ["function", "behaviour", "structure"]
LAYER_INDEX_KEY = {"function": "F", "behaviour": "Be", "structure": "S"}

MODALITY_VOCABULARY = """\
Modality vocabulary (use ONLY these; do not introduce others):
- Touch: direct input on a touch-sensitive display (tap, select, drag).
- Keyboard: physical/virtual keyboard and buttons; text and value entry.
- Screen: visual OUTPUT; information rendered on a display.
- Voice-in: INPUT by recognized voice command (ASR / speech-to-command).
- Audio-out: sound OUTPUT from the system (acoustic alert or synthesized speech/TTS).
- Wearable/HMD: head-mounted device (VR/AR/XR). As INPUT: head/eye-tracking, gestures. As OUTPUT: in-visor display.
- Haptic: tactile / force feedback.
"""

def load_summary():
    p = current_out_dir() / "_summary.json"
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return {}

def save_summary(summary):
    (current_out_dir() / "_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

def load_progress(code):
    p = current_out_dir() / f"{code}_progress.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}

def save_progress(code, layer, entry):
    """entry: {"text": "<conteúdo fechado>", "revisions": <int>}"""
    p = current_out_dir() / f"{code}_progress.json"
    data = load_progress(code)
    data[layer] = entry
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def clear_progress(code):
    p = current_out_dir() / f"{code}_progress.json"
    if p.exists():
        p.unlink()

def append_to_index(layer, label, code, text):
    idx_path = current_out_dir() / "elements_index.json"
    idx = json.loads(idx_path.read_text(encoding="utf-8")) if idx_path.exists() else {"F": [], "Be": [], "S": []}
    idx[layer].append({"label": label, "requirement": code, "text": text})
    idx_path.write_text(json.dumps(idx, indent=2, ensure_ascii=False), encoding="utf-8")

def save_chat(code, messages):
    (current_out_dir() / f"{code}_chat.json").write_text(
        json.dumps(messages, indent=2, ensure_ascii=False), encoding="utf-8")

def load_chat(code):
    p = current_out_dir() / f"{code}_chat.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else []

def clear_chat(code):
    p = current_out_dir() / f"{code}_chat.json"
    if p.exists():
        p.unlink()

def _started_path(code):
    return current_out_dir() / f"{code}_started.txt"

def mark_started(code):
    p = _started_path(code)
    if not p.exists():
        p.write_text(str(time.time()), encoding="utf-8")

def elapsed_wall_s(code):
    p = _started_path(code)
    return round(time.time() - float(p.read_text(encoding="utf-8")), 1) if p.exists() else None

def extract_current_layer(client, layer, messages, on_retry=None, usage_log=None):
    """Extrai do log o fechamento de UMA camada (a corrente), mais quantas
    propostas substancialmente diferentes foram feitas antes do designer
    aceitar (0 se aceitou de primeira). Se a camada ainda não foi de fato
    fechada nesta conversa, retorna erro em vez de inventar conteúdo — é
    isso que evita salvar Behaviour/Structure vazios ou uma recusa do
    modelo (ex.: 'I can't title this behavior without seeing it...')."""
    prompt = (
        f"Has the {layer.upper()} layer been explicitly closed/agreed by the "
        "designer in this conversation? If yes, output ONLY a JSON object (no "
        "prose, no fences):\n"
        '{"text": "<label + full closed statement for this layer>", "revisions": <int>}\n'
        "revisions = how many times a substantively different proposal was made "
        "for this layer before the designer accepted one (0 if accepted on the "
        "first proposal).\n"
        f"If the {layer} layer has NOT been closed yet, output exactly:\n"
        '{"text": "", "revisions": 0}'
    )
    resp = call_with_retry(client, on_retry=on_retry, usage_log=usage_log,
        model=MODEL_MISC, max_tokens=1000, output_config={"effort": EFFORT_MISC},
        system="Return ONLY valid JSON, nothing else.",
        messages=messages + [{"role": "user", "content": prompt}],
    )
    raw = resp.content[0].text.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.strip()
    try:
        d = json.loads(raw)
    except json.JSONDecodeError as e:
        return None, f"parse falhou: {e}"
    if not d.get("text", "").strip():
        return None, f"a camada {layer} ainda não foi fechada nesta conversa — continue a discussão antes de avançar"
    return d, None

def requirement_done(code):
    return (current_out_dir() / f"{code}.json").exists()

def next_pending_requirement():
    for req in REQUIREMENTS:
        if not requirement_done(req["code"]):
            return req
    return None


# ── SUS (System Usability Scale, Brooke 1996 — wording original) ─────────────
SUS_ITEMS = [
    ("I think that I would like to use this system frequently", True),
    ("I found the system unnecessarily complex", False),
    ("I thought the system was easy to use", True),
    ("I think that I would need the support of a technical person to be able to use this system", False),
    ("I found the various functions in this system were well integrated", True),
    ("I thought there was too much inconsistency in this system", False),
    ("I would imagine that most people would learn to use this system very quickly", True),
    ("I found the system very cumbersome to use", False),
    ("I felt very confident using the system", True),
    ("I needed to learn a lot of things before I could get going with this system", False),
]

def sus_score(responses):
    total = 0
    for (_, positive), r in zip(SUS_ITEMS, responses):
        total += (r - 1) if positive else (5 - r)
    return round(total * 2.5, 1)

def sus_done():
    return (current_out_dir() / "sus.json").exists()

def save_sus(responses):
    score = sus_score(responses)
    (current_out_dir() / "sus.json").write_text(json.dumps(
        {"responses": responses, "score": score}, indent=2, ensure_ascii=False), encoding="utf-8")
    return score


# ── toy problem (aquecimento, sempre zero IA, informativo, não bloqueia) ────
def load_toy_requirement():
    return json.loads((CONTENT_DIR / "toy_requirement.json").read_text(encoding="utf-8"))

def toy_status():
    p = current_out_dir() / "toy_status.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {"submitted": False, "acknowledged": False}

def load_toy_submission():
    p = current_out_dir() / "toy_submission.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None

def submit_toy_problem(entries):
    (current_out_dir() / "toy_submission.json").write_text(json.dumps(entries, indent=2, ensure_ascii=False), encoding="utf-8")
    (current_out_dir() / "toy_status.json").write_text(json.dumps(
        {"submitted": True, "acknowledged": False}, indent=2, ensure_ascii=False), encoding="utf-8")

def acknowledge_toy():
    """Designer viu a tela de 'aquecimento concluído' e escolheu seguir em
    frente — não precisa de ninguém aprovar, só registra que ele passou
    por ali."""
    status = toy_status()
    status["acknowledged"] = True
    (current_out_dir() / "toy_status.json").write_text(json.dumps(status, indent=2, ensure_ascii=False), encoding="utf-8")

def reopen_toy():
    """Usado pelo próprio designer, na tela de 'aquecimento concluído', pra
    poder editar e reenviar em vez de seguir com a resposta como está."""
    status = toy_status()
    status["submitted"] = False
    (current_out_dir() / "toy_status.json").write_text(json.dumps(status, indent=2, ensure_ascii=False), encoding="utf-8")



# ── system prompt ─────────────────────────────────────────────────────────────
def fbs_system(prior_summary=None):
    prior_block = ""
    if prior_summary:
        lines = [f"- {code}: {s}" for code, s in prior_summary.items()]
        prior_block = (
            "\n\n=== PRIOR REQUIREMENTS ALREADY DEFINED (for consistency) ===\n"
            + "\n".join(lines)
        )
    return (
        "You are a design engineer assisting in the functional and structural design "
        "of a Multimodal HMI for MUM-T ISR operations, using the Function-Behaviour-"
        "Structure (FBS) ontology.\n\n"
        "Definitions for THIS project:\n"
        "- Function (F): the teleology of the artefact — what it is FOR. It connects "
        "the designer's goals to the artefact's measurable effects. Function must "
        "NOT describe sequence, ordering, guidance logic, confirmation steps, or "
        "any interaction flow — that belongs to Behaviour, not here.\n"
        "- Behaviour (Be): what the artefact DOES — the attributes derivable from "
        "its structure, expressed as the interaction flow that realizes the "
        "function using ONLY the fixed modalities. Provides measurable performance "
        "criteria.\n"
        "- Structure (S): what the artefact CONSISTS OF — its components and their "
        "relationships; the concrete HMI elements that implement the behaviour.\n\n"
        "Cardinality: F, Be and S are NOT 1:1:1 per requirement, and the relationship "
        "isn't purely downward either — a Behaviour can serve multiple Functions, "
        "and a Structure can serve multiple Behaviours/Functions (shared/reused "
        "elements, not duplicated per Function). The dialogue below closes on one "
        "path per layer for tractability, but flag it explicitly when a Be or S "
        "candidate could be shared across Functions rather than being exclusive to "
        "one. Don't preemptively design for reuse in requirements not yet "
        "discussed — flag sharing only when it's relevant to the requirement at "
        "hand. Reuse across the full requirement set gets consolidated later.\n\n"
        "You will discuss ONE layer at a time (Function, then Behaviour, then "
        "Structure) with the human designer. Propose an option, explain your "
        "reasoning briefly, and engage with pushback — if the designer disagrees, "
        "understand their point and either adjust or explain why you'd keep your "
        "suggestion. This is a negotiation, not a one-shot approval.\n\n"
        "IMPORTANT — closing a layer is the designer's action, not yours: once "
        "the designer accepts a candidate, restate its final label clearly and "
        "then STOP. Do not start proposing the next layer's candidates in that "
        "same reply, even if the path forward seems obvious. The interface only "
        "advances when the designer clicks a 'Close layer' button on their end, "
        "and they'll come back to you afterward (e.g. 'ok, propose Behaviour "
        "now') to open the next layer. Jumping ahead just creates a mismatch "
        "between what you've said and what the interface actually shows as "
        "closed.\n\n"
        f"{MODALITY_VOCABULARY}\n\n"
        "=== SYSTEM DESCRIPTION ===\n"
        f"{SYSTEM_DESCRIPTION}\n\n"
        f"{HMI_BASELINE}\n\n"
        f"{RESPONSE_STYLE}"
        f"{prior_block}"
    )


# ── prompts de abertura por camada ────────────────────────────────────────────
def opening_prompt(req):
    code = req["code"]
    r = code[1:]
    mods = " and ".join(req["modalities"])
    return (
        f"Requirement {code} ({req['type']}): {req['name_en']}. "
        f"Fixed modalities: {mods}. Intent: {req['intent']}.\n\n"
        "We will design this requirement in three sequential layers, all within "
        "THIS conversation: Function first, then Behaviour, then Structure. "
        "For each layer: propose, negotiate, and once agreed, state its final "
        "label clearly and STOP there — wait for the designer to close it on "
        "their end and explicitly ask you to open the next layer. Don't move to "
        "the next layer's candidates on your own.\n"
        f"- Functions: propose 2-3 genuinely distinct candidates labeled F-{r}.1, "
        f"F-{r}.2, ... Distinct means each opens a different interaction goal — "
        "not the same goal reworded.\n"
        f"- Behaviours: one distinct interaction idea per fixed modality "
        f"pathway (e.g. one Touch-only, one Keyboard-only), plus a Mixed "
        f"pathway if it adds real value beyond the two. Labeled Be-{r}.<F>.1, "
        f"Be-{r}.<F>.2, ... using the closed F index.\n"
        f"- Structures: 2-3 distinct sets of concrete HMI elements, labeled "
        f"S-{r}.<F>.<Be>.1, ... using the closed F and Be indices.\n\n"
        "Start with the Function candidates now (state the intent back first), "
        "then stop once Function is agreed — the designer closes each layer on "
        "their end and will prompt you when it's time for the next one."
    )


# ── chamadas de API ───────────────────────────────────────────────────────────
def call_with_retry(client, on_retry=None, usage_log=None, **kwargs):
    start = time.time()
    for attempt in range(5):
        try:
            resp = client.messages.create(**kwargs)
            if usage_log is not None:
                usage_log.append({
                    "model": kwargs.get("model"),
                    "input_tokens": resp.usage.input_tokens,
                    "output_tokens": resp.usage.output_tokens,
                    "cache_read_tokens": getattr(resp.usage, "cache_read_input_tokens", 0) or 0,
                    "cache_write_tokens": getattr(resp.usage, "cache_creation_input_tokens", 0) or 0,
                    "elapsed_s": round(time.time() - start, 2),
                })
            return resp
        except (anthropic.APIConnectionError, anthropic.APITimeoutError, anthropic.RateLimitError):
            wait = 2 ** attempt
            if on_retry:
                on_retry(wait)
            time.sleep(wait)
        except anthropic.APIStatusError as e:
            if e.status_code < 500:
                raise  # erro do cliente (ex.: modelo inválido) — não adianta tentar de novo
            wait = 2 ** attempt
            if on_retry:
                on_retry(wait)
            time.sleep(wait)
    raise RuntimeError("Falha de conexão persistente após 5 tentativas.")

def chat_turn(client, system, messages, on_retry=None, usage_log=None):
    """Uma rodada de diálogo. messages já deve conter o último turno do usuário."""
    resp = call_with_retry(client, on_retry=on_retry, usage_log=usage_log,
        model=MODEL, max_tokens=1500, output_config={"effort": EFFORT},
        system=system, messages=messages,
    )
    return resp.content[0].text

def usage_totals(usage_log):
    tin = sum(u["input_tokens"] for u in usage_log)
    tout = sum(u["output_tokens"] for u in usage_log)
    tcache_r = sum(u.get("cache_read_tokens", 0) for u in usage_log)
    tcache_w = sum(u.get("cache_write_tokens", 0) for u in usage_log)
    cost = sum(
        u["input_tokens"] / 1e6 * PRICE_PER_MTOK[u.get("model", MODEL)]["input"]
        + u["output_tokens"] / 1e6 * PRICE_PER_MTOK[u.get("model", MODEL)]["output"]
        for u in usage_log
    )
    return {
        "calls": len(usage_log),
        "input_tokens": tin,
        "output_tokens": tout,
        "cache_read_tokens": tcache_r,
        "cache_write_tokens": tcache_w,
        "total_tokens": tin + tout,
        "elapsed_s": round(sum(u["elapsed_s"] for u in usage_log), 2),
        "cost_usd": round(cost, 4),
    }

def save_usage(code, usage_log, process_stats=None):
    totals = usage_totals(usage_log)
    if process_stats:
        totals.update(process_stats)
    (current_out_dir() / f"{code}_usage.json").write_text(json.dumps(
        {"calls": usage_log, "totals": totals}, indent=2, ensure_ascii=False), encoding="utf-8")
    return totals

def extract_layer_entries(client, layer_key, code, messages, on_retry=None, usage_log=None):
    label_formats = {
        "F": "F<r>.<f>",
        "Be": "Be<r>.<f>.<be>",
        "S": "S<r>.<f>.<be>.<s>",
    }
    prompt = (
        f"Output ONLY a JSON array (no prose, no markdown fences) listing the "
        f"individual {layer_key} elements just closed. Each item: "
        f'{{"label": "...", "requirement": "{code}", "text": "..."}}. '
        f'Label format: {label_formats[layer_key]}, using the r/f/be/s indices from '
        f"this conversation (r = requirement number without leading zero issues, "
        f"e.g. R01 -> 01). One array item per distinct element (e.g. if 3 "
        f"Behaviours were closed, output 3 items)."
    )
    resp = call_with_retry(client, on_retry=on_retry, usage_log=usage_log,
        model=MODEL_MISC, max_tokens=800, output_config={"effort": EFFORT_MISC},
        system="Return ONLY valid JSON, nothing else.",
        messages=messages + [{"role": "user", "content": prompt}],
    )
    raw = resp.content[0].text.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.strip()
    try:
        return json.loads(raw), None
    except json.JSONDecodeError as e:
        return [], f"parse falhou para {layer_key}: {e}"

def summarize_layer(client, text, layer_label, on_retry=None, usage_log=None):
    resp = call_with_retry(client, on_retry=on_retry, usage_log=usage_log,
        model=MODEL_MISC, max_tokens=40, output_config={"effort": EFFORT_MISC},
        messages=[{"role": "user", "content":
            f"In ONE short phrase (max 12 words), title this {layer_label}: {text}"}],
    )
    return resp.content[0].text.strip()

def summarize(client, fbs, on_retry=None, usage_log=None):
    resp = call_with_retry(client, on_retry=on_retry, usage_log=usage_log,
        model=MODEL_MISC, max_tokens=100, output_config={"effort": EFFORT_MISC},
        messages=[{"role": "user", "content":
            "Summarize this FBS decision in ONE short sentence "
            f"(function + key structure choice): {json.dumps(fbs)}"}],
    )
    return resp.content[0].text.strip()


# ── fechamento do requisito ───────────────────────────────────────────────────
def close_requirement(client, req, messages, summary, on_retry=None, usage_log=None):
    """Monta o fechamento final a partir das camadas já extraídas e salvas
    uma a uma via save_progress (a UI só libera avançar de camada depois de
    extract_current_layer confirmar que ela foi de fato fechada — por isso
    aqui é seguro assumir que as três já estão em progress). Alimenta o
    índice, grava artefatos. Retorna (fbs, warnings). usage_log acumula
    tokens/tempo de toda a conversa do requisito (turnos de chat + chamadas
    de fechamento)."""
    code = req["code"]
    warnings = []
    if usage_log is None:
        usage_log = []

    progress = load_progress(code)
    missing = [l for l in LAYERS if not progress.get(l, {}).get("text", "").strip()]
    if missing:
        return None, [f"camadas ainda não fechadas: {missing} — requisito NÃO salvo"]

    for layer, key in LAYER_INDEX_KEY.items():
        entries, e = extract_layer_entries(client, key, code, messages, on_retry, usage_log)
        if e:
            warnings.append(f"índice {key}: {e} — completar manualmente")
        for item in entries:
            append_to_index(key, item["label"], code, item["text"])

    mods = " and ".join(req["modalities"])
    fbs = {
        "code": code, "name_en": req["name_en"], "type": req["type"],
        "modalities": req["modalities"],
        "closed_at": time.time(),
        "function": progress["function"]["text"],
        "function_summary": summarize_layer(client, progress["function"]["text"], "Function", on_retry, usage_log),
        "behaviour": progress["behaviour"]["text"],
        "behaviour_summary": summarize_layer(client, progress["behaviour"]["text"], "Behaviour", on_retry, usage_log),
        "structure": progress["structure"]["text"],
        "structure_summary": summarize_layer(client, progress["structure"]["text"], "Structure", on_retry, usage_log),
    }
    (current_out_dir() / f"{code}.json").write_text(json.dumps(fbs, indent=2, ensure_ascii=False), encoding="utf-8")
    (current_out_dir() / f"{code}_log.json").write_text(json.dumps(messages, indent=2, ensure_ascii=False), encoding="utf-8")
    (current_out_dir() / f"{code}_summary.md").write_text(
        f"# {code} — {req['name_en']} ({req['type']})\n\n"
        f"**Modalities:** {mods}\n\n"
        f"## Function\n{fbs['function']}\n\n"
        f"## Behaviour\n{fbs['behaviour']}\n\n"
        f"## Structure\n{fbs['structure']}\n", encoding="utf-8")
    summary[code] = summarize(client, fbs, on_retry, usage_log)
    save_summary(summary)

    process_stats = {
        "user_turns": sum(1 for m in messages if m["role"] == "user"),
        "revisions": {l: progress[l].get("revisions", 0) for l in LAYERS},
        "wall_clock_s": elapsed_wall_s(code),
    }
    totals = save_usage(code, usage_log, process_stats)
    clear_chat(code)
    clear_progress(code)
    _started_path(code).unlink(missing_ok=True)
    return fbs, warnings


# ── revisão de requisito já fechado ───────────────────────────────────────────
def reopen_requirement(code):
    """Designer decidiu revisar um requisito já fechado. Arquiva o
    fechamento antigo (não perde o dado) e libera o código pra ser refeito.
    Retorna (closed_at antigo, conteúdo antigo de {code}_log.json) — o
    primeiro pra saber quem foi fechado depois, o segundo pra quem quiser
    recarregar o conteúdo anterior pra edição."""
    p = current_out_dir() / f"{code}.json"
    old = json.loads(p.read_text(encoding="utf-8"))
    old_closed_at = old.get("closed_at")
    old_log_path = current_out_dir() / f"{code}_log.json"
    old_log = json.loads(old_log_path.read_text(encoding="utf-8")) if old_log_path.exists() else None
    n = 1
    while (current_out_dir() / f"{code}_prev{n}.json").exists():
        n += 1
    p.rename(current_out_dir() / f"{code}_prev{n}.json")
    for suffix in ("_log.json", "_summary.md", "_usage.json"):
        src = current_out_dir() / f"{code}{suffix}"
        if src.exists():
            src.rename(current_out_dir() / f"{code}_prev{n}{suffix}")
    return old_closed_at, old_log

def downstream_affected(code, old_closed_at):
    """Requisitos já fechados depois de `code` (podem ter usado a versão
    antiga dele como parte do contexto de consistência)."""
    if old_closed_at is None:
        return []
    affected = []
    for req in REQUIREMENTS:
        other = req["code"]
        if other == code:
            continue
        p = current_out_dir() / f"{other}.json"
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            if data.get("closed_at", 0) > old_closed_at:
                affected.append(other)
    return affected