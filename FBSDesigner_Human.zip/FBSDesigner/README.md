# FBSDesigner — condição Human

Interface usada na pesquisa de doutorado sobre design de HMI assistido por IA (estudo de caso MUM-T/ISR). Você define, requisito por requisito, como partes da interface devem funcionar usando o método Function-Behaviour-Structure (FBS). Na sua condição (**Human**) você trabalha sozinho, **sem nenhuma assistência de IA**: não há chave de API nem conexão com modelos de linguagem.

## 1. Instalação

### O que você precisa
- **Python 3** (qualquer versão recente), de https://www.python.org/downloads/. No Windows, marque **"Add Python to PATH"** na instalação.
- Um navegador (Chrome, Firefox, Edge...).
- Internet apenas na primeira vez, para instalar os pacotes.

### Passo a passo
1. Extraia o `.zip` numa pasta qualquer.
2. Inicie o app:
   - **Windows:** dois cliques em `iniciar_human.bat`
   - **Mac/Linux:** `bash iniciar_human.sh` num terminal aberto na pasta
3. Na primeira vez demora alguns minutos (cria um ambiente próprio e instala o Streamlit). Só acontece uma vez.
4. O navegador abre sozinho (`http://localhost:8501`). **Mantenha a janela preta/terminal aberta enquanto usa**; fechá-la encerra o app.

Para abrir de novo, repita o mesmo clique/comando. Seu progresso é mantido.

### Se algo der errado
- **"Python não encontrado":** instale o Python (no Windows, com "Add Python to PATH") e rode de novo.
- **Mac/Linux, "permission denied":** use `bash iniciar_human.sh`.
- **Janela fecha sozinha / erro estranho:** rode com `--debug` (`iniciar_human.bat --debug` ou `bash iniciar_human.sh --debug`); ele pausa a cada etapa. Mande uma captura de tela ao pesquisador.
- **A página não abre:** acesse manualmente http://localhost:8501.

## 2. Uso

1. **Identificação:** digite o seu número de participante (2 dígitos, passado pelo pesquisador). Na primeira vez, preencha o formulário curto de perfil profissional.
2. **Introdução:** leia as definições do método, o vocabulário de modalidades e o contexto do cenário. Na barra lateral há, a qualquer momento, um **exemplo preenchido** e as **imagens das telas já existentes** do sistema.
3. **Aquecimento:** um problema simples de prática, fora do domínio do projeto.
4. **Requisitos reais (20):** um de cada vez. Para cada um você escreve as três camadas, nesta ordem:
   - **Function:** para que serve (objetivo/efeito). Sem fluxo nem passos.
   - **Behaviour:** o que faz ("o usuário faz X, o sistema responde Y"), sem componentes concretos.
   - **Structure:** do que é feito (botões, painéis, ícones, alto-falantes...) e **como se relacionam** para viabilizar o Behaviour.

   As modalidades de interação já vêm fixadas em cada requisito.
5. **Questionário final:** um questionário curto (SUS) sobre a experiência de usar a *ferramenta*.

**Várias sessões:** você pode parar e voltar quando quiser; digite o mesmo número de participante e o app retoma de onde parou. Tempo estimado total: 4 a 6 horas de trabalho ativo.

## 3. Devolvendo os resultados

Tudo o que você produz fica na pasta **`out/`**, dentro da pasta do projeto. Ao terminar (ou quando o pesquisador pedir), compacte a pasta `out` num `.zip` e envie ao pesquisador.

**Privacidade:** não é coletado nome, e-mail ou qualquer dado que identifique você diretamente, só o número de participante e as respostas do perfil profissional.
